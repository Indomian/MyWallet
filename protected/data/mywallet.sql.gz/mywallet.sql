-- phpMyAdmin SQL Dump
-- version 3.4.5deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 26 2012 г., 00:33
-- Версия сервера: 5.1.63
-- Версия PHP: 5.3.6-13ubuntu3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `mywallet`
--

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL COMMENT 'Shows that account has a parent with particular ID',
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` enum('main','normal','costs') NOT NULL,
  `summ` int(11) NOT NULL,
  `date_operation` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `accounts`
--

INSERT INTO `accounts` (`id`, `parent_id`, `user_id`, `title`, `type`, `summ`, `date_operation`) VALUES
(1, 0, 1, 'Общий счёт', 'main', 0, '0000-00-00'),
(2, 0, 2, 'Test access', 'costs', 503000, '2012-09-26'),
(3, 0, 1, 'Оплата квартиры', 'costs', 0, '0000-00-00');

-- --------------------------------------------------------

--
-- Структура таблицы `AuthAssignment`
--

CREATE TABLE IF NOT EXISTS `AuthAssignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `AuthAssignment`
--

INSERT INTO `AuthAssignment` (`itemname`, `userid`, `bizrule`, `data`) VALUES
('User', '1', NULL, NULL),
('User', '2', NULL, NULL),
('User', '3', NULL, 'N;');

-- --------------------------------------------------------

--
-- Структура таблицы `AuthItem`
--

CREATE TABLE IF NOT EXISTS `AuthItem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `AuthItem`
--

INSERT INTO `AuthItem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('accounts/create', 0, 'Access to creation accounts', NULL, NULL),
('accounts/index', 0, 'Acccess to accounts listing', NULL, NULL),
('accounts/manage', 0, 'Access to manage accounts', NULL, NULL),
('accounts/update', 0, 'Access check for editing account', NULL, NULL),
('accounts/view', 0, 'Access to view accounts operation', NULL, NULL),
('Guest', 2, 'Base guest user, everyone is a guest', NULL, NULL),
('operations/create', 0, 'Operation allowing creation of operations', NULL, NULL),
('operations/index', 0, 'Access to operations list page', NULL, NULL),
('operations/view', 0, 'Access to view of operations', NULL, NULL),
('site/error', 0, 'Access to error pages', NULL, NULL),
('site/index', 0, 'Access to main site page', NULL, NULL),
('site/login', 0, 'Access to site authorization', NULL, NULL),
('site/logout', 0, 'Access to logout function', NULL, NULL),
('site/register', 0, 'Access to register function', NULL, NULL),
('User', 2, 'Basic user, can operate his own account', NULL, NULL),
('users/index', 0, 'Access to index page of users managment', NULL, NULL),
('users/view', 0, 'Access to user account view', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `AuthItemChild`
--

CREATE TABLE IF NOT EXISTS `AuthItemChild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `AuthItemChild`
--

INSERT INTO `AuthItemChild` (`parent`, `child`) VALUES
('User', 'accounts/create'),
('User', 'accounts/index'),
('User', 'accounts/manage'),
('User', 'accounts/update'),
('User', 'accounts/view'),
('User', 'Guest'),
('User', 'operations/create'),
('User', 'operations/index'),
('User', 'operations/view'),
('Guest', 'site/error'),
('Guest', 'site/index'),
('Guest', 'site/login'),
('Guest', 'site/logout'),
('User', 'site/logout'),
('Guest', 'site/register'),
('User', 'users/index'),
('User', 'users/view');

-- --------------------------------------------------------

--
-- Структура таблицы `operations`
--

CREATE TABLE IF NOT EXISTS `operations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_account_id` int(11) NOT NULL,
  `to_account_id` int(11) NOT NULL,
  `summ` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `operations`
--

INSERT INTO `operations` (`id`, `from_account_id`, `to_account_id`, `summ`, `title`, `date`) VALUES
(1, 0, 1, 3800000, 'Заработная плата', '2012-09-10 21:00:00'),
(2, 0, 2, 3000, 'Зачисление средств', '2012-09-26 00:25:10'),
(3, 0, 2, 500000, 'Добавление 5000 на счёт, сейчас должны отображаться как 500000', '2012-09-26 00:29:04');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `active`) VALUES
(1, 'bolgov', 'b9f470954c62ade4dc4eb2d3284f1eb6', 1),
(2, 'blade39', 'b9f470954c62ade4dc4eb2d3284f1eb6', 1),
(3, 'BlaDe', 'b9f470954c62ade4dc4eb2d3284f1eb6', 1);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `AuthAssignment`
--
ALTER TABLE `AuthAssignment`
  ADD CONSTRAINT `AuthAssignment_ibfk_1` FOREIGN KEY (`itemname`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `AuthItemChild`
--
ALTER TABLE `AuthItemChild`
  ADD CONSTRAINT `AuthItemChild_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `AuthItemChild_ibfk_2` FOREIGN KEY (`child`) REFERENCES `AuthItem` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
